# Cross-Disease scGATES Result Summary

## Core Results

All rows use Full scGATES without synthetic text or cell noise.

| Disease / Dataset | R@1 | R@5 | R@10 | MRR |
|---|---:|---:|---:|---:|
| Alzheimer disease / SEA-AD | 0.615 | 0.858 | 0.905 | 0.720 |
| Colorectal cancer | 0.511 | 0.817 | 0.882 | 0.647 |
| Lung cancer | 0.611 | 0.911 | 0.956 | 0.738 |

## Cancer Cross-Dataset Details

| Dataset | Split | R@1 | R@5 | R@10 | MRR |
|---|---|---:|---:|---:|---:|
| Colorectal cancer | patient-heldout | 0.511 | 0.817 | 0.882 | 0.647 |
| Lung cancer | donor-heldout | 0.611 | 0.911 | 0.956 | 0.738 |

## Interpretation Notes

- The cancer experiments evaluate cross-disease applicability using cancer-specific literature evidence and Geneformer-derived contextual gene distributions.
- Lung cancer used a larger cancer-only cell set than colorectal cancer, with 12533 candidate cells and a donor-heldout split.
- Lung cancer text evidence was available as sentence plus Ensembl ID pairs, without PMID or year metadata. Colorectal cancer text evidence contained richer CancerAlterome metadata.
